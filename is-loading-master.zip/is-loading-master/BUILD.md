# Build steps

1. Update package.json version
2. `yarn pub`
